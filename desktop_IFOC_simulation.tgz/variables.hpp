#ifndef VARIABLES_H
#define VARIABLES_H

#include "ClarkeParkTransforms.cpp"
#include "my_fp.h"
using namespace Maths;

//#define NODECOUPLING 1


#define vel_d 0
//#define vel_Min_pid_res -360.0//?		//Min value PI out
//#define vel_Max_pid_res 360.0//?		//Max value PI out
//#define ACCEL 7.7 //7.7km/h per sec
#define vel_cel 2.0// (0.03*15)//alterei(0.03*10)//?TODO					//max aceleration at setpoint

//TODO_ insert values and descoment in end #define torque_control_p 128//without current control_y 1.4//0.33//3.6// ?
//TODO_ insert values and descoment in end #define torque_control_i 0.000008//0.01// ?
#define torque_control_d 0.0
#define torque_control_Min_pid_res -400.0//changed with iqmax//TODO alterei isto391.0?
#define torque_control_Max_pid_res 400.0//?
#define torque_control_cel 8//400.0//?

#ifdef NODECOUPLING
#define current_control_q_i 0.0005 //0.00022 0.0000005//0.00005(0.00625)//0.0625//?
#define current_control_q_d 0.0//?
#else
#define current_control_q_i 0.0006//0.00022 0.0000005//0.00005(0.00625)//0.0625//?
#define current_control_q_d 0.0//?
#endif
//#define 
//extern float current_control_q_Min_pid_res;// -8.8//8.0 7.7//TODO alterei isto7.0 (-6.45)//(-100) ////TODO??!! valor mt baixo, pk? //Attention to set this value to another motor
//#define 
//extern float current_control_q_Max_pid_res;// 8.8//6.45//100//
#define current_control_q_cel 1.0//(3.0)// 3000//?


//TODO_ insert values and descoment in end #define current_control_d_p 0.54//1.9//? 
//TODO_ insert values and descoment in end #define current_control_d_i 0.00001//0.001//?
#define current_control_d_d 0.0
#define current_control_d_Min_pid_res -100//29//(-100.0 )// -100?mudei TODO
#define current_control_d_Max_pid_res 100//29//(100.0 )//100?mudei TODO
#define current_control_d_cel 1.0//0.05//0.04//?mudei


//TODO remove at end the folloving block, replace for defines
//PI controllers values
	extern float vel_p ;//= 20.0 ;////20.0;//6;//1000;//1;//1//9/ /1.1//(3)//6.0*0.9//(2/*4.5*/)//TODO: speed controller gain 
	extern float vel_i ;//= 0.0;//006 ;//0.00006;//TODO: speed controller integral gain 

	extern float torque_control_p ;//= /*to use current controller */ 10 /*estava este val em torq_control:0.33,mas experimentei c 1.4;*//* e deu bons result.*//*3.6*0.124*/;//alterei*0.5 TODO: torque controller gain
	extern float torque_control_i ;//= 0.0001;//8 /*alterei0.0009(0.001) 0.008*///TODO: torque controller integral gain

	extern float current_control_d_p ;//= 1.1;//2.2 ;//mudei0.54;//0.5 a experiencia tava 0.6
	extern float current_control_d_i ;//= 0.0001 ;//mudei0.0004 0.00001;<---testes otem 0.03

	//extern float current_control_q_p ;//= 0.096;//here1.56 ;//2.0*0.99/*new 1.56*//*1.4*//*0.64/*0.082 1.0*/;
	extern float current_control_q_Max_pid_res ;//= 8.8 ;//* 1.28;//1.9//*3 better ef, but bigger over tension//*1.5;//*1.29;//new TODO
	extern float current_control_q_Min_pid_res ;//= -8.8 ;//* 3;//* 3 better """"";//*1.29;//new TODO doing

//#define FP 1 //FLOATP 1 //or mixed ( #define FP e #define FP

#define FLOATP 1

extern float T , T_8khz , T_16khz ;
extern float IDC;
extern long n;

#ifdef FLOATP

extern float Vmax ;	//Vmax = VDC/CONST_SQRT3_ (voltage circle module) 
extern float VDC ;//battery voltage
extern s32fp FP_VDC;
extern s32fp FP_Vmax;
#else
#ifdef FP

extern s32fp FP_VDC;
extern s32fp FP_Vmax;
//TODO FP
extern float VDC;
extern float Vmax;


#else

extern float Vmax;	//Vmax = VDC/CONST_SQRT3_ (voltage circle module)//TODO JAN
extern float VDC;//battery voltage


#endif

#endif
extern s32fp FP_1, FP_Rm, FP_M , FP_Llr , FP_Rr_est , FP__1 , FP_0;//TODO REMOVE?
#define FP_Lr FP_FROMFLT(Lr)//TODO calc const to efic

/*TODO FP */extern tTwoPhaseDQ VDQ_rtc;//used to estimate Rotor time constant

extern float w_ref, wr;

extern float _fds,_fqs, ids_ant, iqs_ant;
extern float fds_,fqs_;

extern float T0,T1,T2;
extern int a1,b1,c1,a2,b2,c2;

extern bool SIGNAL_bat_full;

extern float Rr;//TODO needed??
extern float Rr_initial;//TODO remove at end

extern float IDQ_d_min;// 50//(71.0*0.7)
extern float IDCmin;
extern float IDCmax;
extern bool IDC_min_flag;
//extern bool IDC_less_than_min;
extern s32fp set_point_previous;
extern s32fp set_point_previous_v;
extern bool Flag_reset_controller_idq_q;
extern u_int8_t it_exc_v;//number of iterations in while cycle when voltage exceed the limit
//extern  float IDQ_D_MIN;//TODO //ID_MIN 50//Min. rotor magnetization current(Idq.d) .This value is changed with velocity

extern bool primeiro;
//new
extern int time_bin_max;
extern int time_betw_bin_max;
extern float temperatur_motor;
//#define FLOATP 1

#define  TIME_BIN_MAX 4.2/*6.38*/*1.0/T
//new
#define TIME_IDCMIN_MAX 9.2/*6.38*/*1.0/T//10 s but i do cag.
extern int time_IDCmin;
extern int time_betw_IDCmin_max ;
extern float temperatur_battery ;

#define IDC_MIN_MAX (-80*1.5*0.9)//-200
#define IDC_MIN (-80*1.0*0.9)//ah * 0.5c * cag.
extern bool flag_decrease_idq_q;
 
//new
#define IDQ_D_MIN 63//81//50 60 86 92.14(91.14), 90 .23, 94 .33 ;98. 92.42(91.36 com 4 velocidadde de caixa, 91.60 com mudança de valores aquando das reducoes

#define M 0.001500//? mutual inductance
#define Llr 0.000140//?
#define Rm 200//650.0//? represents eddy currents. TODO_ don't know this value

extern float Lr ;//= (Llr+M) ;
extern float M_M ;//= (M*M);
extern float M_M__Rm ;//= (M*M/Rm);
extern float M_M_Llr_Llr__Rm__Lr__Lr ;//= (M*M*Llr*Llr/Rm/Lr/Lr);
extern s32fp FP_M_M;// = FP_FROMFLT(M*M) ;
extern float Imax_Imax_ro_ro ;
extern float ro_ro_Ls_Ls_Ls_Ls , ro_ro; 
#define PI	3.14159265358979

#define np 2.0//? number pair poles




#ifdef FP
#endif

extern float Rr_est;

extern float Wn, Wc;

extern bool flag_no_torque_motor;

//IGBT values
#define TURN_ON_DELAY_TIME 0.00000012 //TODO put the values of igts, 0.12us
#define RISE_TIME 0.00000006
#define TURN_OFF_DELAY_TIME 0.00000052
#define FALL_TIME 0.00000007
#define T_R_T_F_TIMES  (TURN_ON_DELAY_TIME + RISE_TIME + TURN_OFF_DELAY_TIME + FALL_TIME) 

#endif
